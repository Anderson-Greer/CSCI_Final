------------------------
HOW TO COMPILE AND RUN
------------------------
Compile: g++ -std=c++17 gameDriver.cpp
Run: ./a.out
------------------------
DEPENDENCIES
------------------------
All files must be located in the same directory.
------------------------
SUBMISSION INFORMATION
------------------------
CSCI1300 Fall 2022 Project 3

Author 1: Anderson Greer | Recitation: 101 - Morgan Byers

Author 2: George Frommell | Recitation: 308 - Baljot Kaur

Date: Dec 1, 2022
------------------------
ABOUT THIS PROJECT
------------------------
This project is a game based on the Dungeon Escape game outline that was provided. 
A player forms a party with four companions and attempts to escape the dungeon.
The player must navigate the dungeon while defeating monsters, interacting with
NPCs, and exploring new rooms. 
